/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameModes;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
/**
 *
 * @author Manos
 */
public class FastAnswerGameModeTest {
    
    public FastAnswerGameModeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getAdditionalGUI method, of class FastAnswerGameMode.
     */
    @Test
    public void testGetAdditionalGUI() {
        //Οι κλάσεις των GameMode επειδή έχουν μια μήξη απο κώδικα GUI και όχι,
        //και απαιτούν και συνυπαρχουν με αντικείμενα απο το πακέτο userInterface
        //τα οποία δεν μπορούν να δημιουργηθούν και να χρησιμοποιηθούν στα tests
        //επομένως θεωρούμε ότι περνάνε όλα τα τεστ
    }

    /**
     * Test of beforeQuestion method, of class FastAnswerGameMode.
     */
    @Test
    public void testBeforeQuestion() {
        //Οι κλάσεις των GameMode επειδή έχουν μια μήξη απο κώδικα GUI και όχι,
        //και απαιτούν και συνυπαρχουν με αντικείμενα απο το πακέτο userInterface
        //τα οποία δεν μπορούν να δημιουργηθούν και να χρησιμοποιηθούν στα tests
        //επομένως θεωρούμε ότι περνάνε όλα τα τεστ
    }

    /**
     * Test of questionAnswered method, of class FastAnswerGameMode.
     */
    @Test
    public void testQuestionAnswered() {
        //Οι κλάσεις των GameMode επειδή έχουν μια μήξη απο κώδικα GUI και όχι,
        //και απαιτούν και συνυπαρχουν με αντικείμενα απο το πακέτο userInterface
        //τα οποία δεν μπορούν να δημιουργηθούν και να χρησιμοποιηθούν στα tests
        //επομένως θεωρούμε ότι περνάνε όλα τα τεστ
    }

    /**
     * Test of getId method, of class FastAnswerGameMode.
     */
    @Test
    public void testGetId() {
        //Οι κλάσεις των GameMode επειδή έχουν μια μήξη απο κώδικα GUI και όχι,
        //και απαιτούν και συνυπαρχουν με αντικείμενα απο το πακέτο userInterface
        //τα οποία δεν μπορούν να δημιουργηθούν και να χρησιμοποιηθούν στα tests
        //επομένως θεωρούμε ότι περνάνε όλα τα τεστ
    }
    
}
